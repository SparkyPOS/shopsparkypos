<?php

return [
    'name' => 'MultiVendor'
];

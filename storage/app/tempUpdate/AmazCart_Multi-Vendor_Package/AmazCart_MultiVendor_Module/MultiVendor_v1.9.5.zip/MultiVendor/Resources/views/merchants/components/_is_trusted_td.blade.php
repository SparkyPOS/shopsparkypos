@if (@$seller->is_trusted == 1)
    <i class="ti-check"></i>
@else
    <i class="ti-close"></i>
@endif

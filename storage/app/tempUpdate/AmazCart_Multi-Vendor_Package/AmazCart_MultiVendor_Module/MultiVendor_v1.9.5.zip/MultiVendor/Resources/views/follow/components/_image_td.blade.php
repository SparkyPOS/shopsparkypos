<div class="image_div">
    <img src="{{showImage(@$data->customer->photo??'frontend/default/img/avatar.jpg')}}" alt="">
</div>